# log-draw

A browser library for drawing composite wireline logs on canvas.

## Install

```sh
npm install log-draw
```

## Usage

Import the classes into a browser application and provide an element to contain
the canvases:

```js
import { CompositeLog } from "log-draw";

const compositeLog = new CompositeLog(document.getElementById("mycanvas"));
const track = compositeLog.addTrack();
track.addLog({
  depth: [100, 101, 102],
  gr: [40, 55, 35]
});
compositeLog.draw();
```

`Log`, `LogTrack`, and `CompositeLog` are exported from the package. `LogTrack`
accepts optional `meta` and `header` objects:

```js
const track = compositeLog.addTrack({
  meta: { name: "Gamma Ray" },
  header: { unit: "gAPI" }
});
```

The package is an ES module and requires a browser environment with the DOM and
Canvas APIs. To add dependencies for development or runtime use, install them
with npm, for example `npm install <package>`.

## Development

```sh
npm install
npm run check
```

Open `index.html` through a local web server to run the included demo.
