

export class Log {
  constructor(parentElement, data){
    let canvas = document.createElement("canvas");
    parentElement.appendChild(canvas);
    canvas.height = '5000';
    canvas.width = '5000';
    this.ctx = canvas.getContext('2d');
    this.data = data;
    this.min = 0;
    this.max = 300;
  }
  drawPath(start){
    let x_start = start+75;
    this.ctx.beginPath();
    this.ctx.moveTo(x_start, 50);
    this.ctx.lineTo(x_start-5, 75);
    this.ctx.lineTo(x_start, 100);
    this.ctx.lineTo(x_start, 10000);
    this.ctx.stroke();
  }
  draw(){
    const {depth, gr} = this.data;
    let prevDepth = 0;
    this.ctx.beginPath();
    for(let i = 0 ; i < depth.length ; i++){
      if(gr[i] != -999.25){
        this.ctx.lineTo(gr[i], 50+i*2)
      }
    }
    this.ctx.stroke();
  }
}

export class LogTrack {
  constructor(parentElement, {meta = {}, header = {}} = {}) {
    this.parentElement = parentElement;
    this.meta = meta;
    this.header = header;
    this.logs = [];
  }
  addLog(data) {
    const log = new Log(this.parentElement, data);
    this.logs.push(log);
    return log;
  }
  draw() {
    this.logs.forEach(log => log.draw());
  }
}

export class CompositeLog {
  constructor(parentElement) {
    this.parentElement = parentElement;
    this.tracks = [];
  }
  addTrack(options) {
    const track = new LogTrack(this.parentElement, options);
    this.tracks.push(track);
    return track;
  }
  draw() {
    this.tracks.forEach(track => track.draw());
  }
}
